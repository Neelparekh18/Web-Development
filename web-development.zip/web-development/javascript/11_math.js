// console.log("hello math");

// Math.E        // returns Euler's number
// Math.PI       // returns PI
// Math.SQRT2    // returns the square root of 2
// Math.SQRT1_2  // returns the square root of 1/2
// Math.LN2      // returns the natural logarithm of 2
// Math.LN10     // returns the natural logarithm of 10
// Math.LOG2E    // returns base 2 logarithm of E
// Math.LOG10E   // returns base 10 logarithm of E

// console.log(Math.PI)
// console.log(Math.E)
// console.log(Math.SQRT2)
// console.log(Math.log10(2))

// round (round figure value aapse)

// console.log(Math.round(1.0))
// console.log(Math.round(-55.67))

// ceil (rounded up value)

// console.log(Math.ceil(0.3));
// console.log(Math.ceil(-66.9))

// floor (rounded down value)
// console.log(Math.floor(0.3));
// console.log(Math.floor(-66.9))

// trunc (only integer value aapse)

// integer and float

// console.log(Math.trunc(22.78))
// console.log(Math.trunc(-22.78))

// Random

// limit (0 to 0.999999999) 0 include and 1 exclude

// const r = Math.random();
// console.log(r)

// const otp = Math.random() * 10000;
// console.log(Math.floor(otp))

// print 0 to 9

// const r = Math.random()*10;
// const final = Math.floor(r);
// console.log(final)

// print 1 to 9

// const r = Math.random()*10;
// const final =  Math.floor(r) + 1;
// console.log(final)

// otp - 4 digit  (min- 1000 , max- 9999)

// proper random function

// function getRndInteger(min, max) {
//     console.log(Math.floor(Math.random() * (max - min + 1) ) + min);
//   }
// getRndInteger(1000,9999)
