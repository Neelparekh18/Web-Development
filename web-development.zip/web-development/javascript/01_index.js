// console.log("hello from external js script")
// let mahir = "sheth"
// console.log("mahir")

// const x = 10;
// console.log(x)
//
