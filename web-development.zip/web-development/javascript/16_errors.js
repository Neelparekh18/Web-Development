// console.log("Try-catch");

// Error handling mate use thaay ---------

// 1.try block
// 2.catch block
// 3.throw statement
// 4.finally statement

// 1. try block ma aapdo code execute kraayisu ke je successfull run thato hoi

// 2.catch block ma aapde aapda code ni errors catch krisu

// syntax ---(try...catch...)

// try {
//     // code
//     console.log(mahir)

// } catch (dax) {
//     console.log(dax)
// }

// console.log(mahir)

// try {
//     // let x = 10;
//     if(x==10){
//         console.log("true")
//     }

// } catch (error) {
//     console.log(error)
// }

// 3. throw statement  - (custom errors provide krse)

// function mahir(x){
//     // console.log(x);
//     if(x == undefined){
//     throw new Error("x ne value madti nathi")
//     }
// }

// try {
//         mahir();
// } catch (error) {
//     console.log(error)
// }

// 4. finally statement - (try block or catch block pachhi run thase finally statement )

// try {
//   // let x = 10;
//   if (x == 10) {
//     console.log("true");
//   }
// } catch (error) {
//   console.log(error);
// } finally{
//     console.log("maro code ahiya pati gayo")
// }

// ------------------

// try {
//   let x = 10;
//   if (x == 10) {
//     console.log("true");
//   }
// } catch (error) {
//   console.log(error);
// } finally {
//   console.log("maro code ahiya pati gayo");
// }
