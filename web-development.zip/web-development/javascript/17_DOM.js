// console.log("dom - Document object model");

// it means JavaScript throw html, css na content ma changes kri skisu

// document.getElementById("name").innerHTML = "NEEL";
