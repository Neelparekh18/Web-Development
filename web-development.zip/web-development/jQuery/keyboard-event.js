$(document).ready(function(){
    // $("#name").keypress(function(){
    //     alert("tame keypress kri")
    // })

    // $("#email").keydown(function(){
    //     alert("tame keydown kri")
    // })
    // $("#pass").keyup(function(){
    //     alert("tame keyup kri")
    // })
})