// syntax

$(document).ready(function () {
  // selector And events -----------------------------

  // $("selector").event(function(){

  // })

  $("#demo1").text("hello from jQuery");

  $(".h2").text("h2 from jQuery");

  $("h4").text("h4 tag");

  // css syntax ---------------------

  // $("selector").css("propertyName","value")

  // $("#d1").css("background-color","yellow")

    $("#btn").click(function () {
      $("#p").css("display", "none");
    // $("#p").css("background-color","yellow")
    });

    $("#btn1").click(function(){
      $("#p").css("display","block")
    })

  // hide and show------------------------

//   $("#btn").click(function () {
//     $("#p").hide();
//   });

//   $("#btn1").click(function () {
//     $("#p").show();
//   });



});
