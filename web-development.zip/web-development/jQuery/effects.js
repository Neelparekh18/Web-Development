$(document).reaDY(function(){



    // fade effect 
    //  fadeIn,fadeOut,fadeToggle 


    






})