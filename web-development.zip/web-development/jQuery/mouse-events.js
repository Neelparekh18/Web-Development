$(document).ready(function(){


    // click -------------------

    $("#btn").click(function(){
        $("#im").show();
    })


    // $("#btn").dblclick(function(){
    //     $("#im").show();
    // })


    // $("#btn").mouseenter(function(){
    //     $("#im").show();
       
    // })

    // $("#btn").mouseleave(function(){
    //     $("#im").hide();
        

    // })



    // $("#inp").mousedown(function(){
    //     alert("mouse down thayuuu");
    // })

    // $("#inp").mouseup(function(){
    //     alert("mouse up thayuuu");
    // })



    $(".inp").focus(function(){
        $(this).css("background-color","red")
    })

    $(".inp").blur(function(){
        $(this).css("background-color","green")
    })
})