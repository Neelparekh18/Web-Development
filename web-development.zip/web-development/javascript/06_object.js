// console.log("hello object");

// syntax --------------

// const obj = {car:"audi", office:"maxgen",name:"mahir"}

// const obj = {
//     car:"audi",
//     office:"maxgen",
//     name:"mahir"
// }

// const complex = {
//     first:"ca",
//     ground:"Apple",
//     third:"maxgen",
//     second:"advocate",
//     it:"maxgen",
//     ca:"xyz"
// }
// console.log(complex.first);
// console.log(complex.ground);
// console.log(complex.third);
// console.log(complex.ca);

// array mate ---
// const complex1 = ["ca","apple","maxgen"];
// console.log(complex1[0])

// const cricket = {
//     batsman:"kohli",
//     bolwer:"jadeja",
//     allrounder:"pandya",
//     keeper:"dhoni"
// }
// console.log(cricket.batsman)
// console.log(cricket.bolwer)
// console.log(cricket.allrounder)
// console.log(cricket.keeper)

// const person = {

// };

//  console.log(person);

// person.name = "mahir"
// person.age = 19
// person.hobby = "tapatap"
// console.log(person)

// this keyword-------------

// const car = {
//     name:"ford",
//     model:1969,
//     color:"red",
//     detail : function(){
//         return this.name + " "+ this.model+" "+this.color
//     }
// }

// console.log(car.name);
// console.log(car.detail())
