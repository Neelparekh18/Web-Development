// console.log("hello map kem cho ?")

// create a new map and Syntax

// const m = new Map([
//     ["apples", 500],
//     ["bananas", 300],
//     ["oranges", 200]
//   ]);
// console.log(m)

// 1. set method ---------------------------

// m.set("name","mahir")
// console.log(m)

// 2. get method ------------------------------

// console.log(m.get("apples"));
// console.log(m.get("bananas"));
// console.log(m.get("oranges"));
// console.log(m.get("name"));

// 3. delete method ----------------------------------------

// m.delete("apples");
// console.log(m.size)

// 4. has method -----------------------------

// const m = new Map([
//     ["apples", 500],
//     ["bananas", 300],
//     ["oranges", 200]
//   ]);

// console.log(m.has("name"));
// console.log(m.has("bananas"));

// 5. forEach method -----------------------

// m.forEach((x)=>{
//     console.log(x);
// })

// 6. entries method -------------------

// console.log(m.entries())

// 7. size method -------------------

// console.log(m.size)
