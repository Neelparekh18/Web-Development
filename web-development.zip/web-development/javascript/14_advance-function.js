// console.log("advance function");

// syntax ---------------------------

// function func(a,b){
//     console.log("hello from normal fucntion");
// }
// func(1,2);

//1. Arrow function ----------------------
// => function keyword remove thase
// => function name as a variable name jatu rehse

// const func1 = ()=>{
// console.log("hello from arrow function")
// }

// func1();

// 2. callback function ---------------------------------

// => min 2 function hova jaruri che
// => ek function nu calling bija function ma as a argument pass krie tene callback function kehvay

// function fun1(){
//     return "hello"
// }

// function fun2(x,y){
// console.log(x)
// }
// fun2(fun1(), 10 )

// e.g----------

// function myDisplayer(something) {
//    console.log(something)
//   }

//   function myCalculator(num1, num2, myCallback) {
//     let sum = num1 + num2;
//     myCallback(sum);  //myDisplayer(10)
//   }

//   myCalculator(5, 5, myDisplayer);

//   --------------------------
// num1 = 5, num2 = 5, myCallback = myDisplayer

// Question: make functions named mahir and dax and make function callbackable

// function mahir (kaik){
//     console.log(kaik)
// }

// function dax(n1, n2, neel){
//     let sum = n1 * n2;
//     neel(sum);
// }

// dax(10, 20, mahir);
