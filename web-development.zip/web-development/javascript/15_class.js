// console.log("hello class aavu badhu tare na karay have tu moto thai gayo che....")

// syntax ---------------------------------

// class mahir{

// class ni sathe farajiyat hovu joiee (constructor method)

// constructor(){

// }

// func(){

// }

// func1(){

// }
// func2(){

// }

// }

// normal func ---
// function fun(){

// }

// class maxgen{

//     constructor(a,b){
//         console.log(a, "constructor vado a")
//     }

//     mahir(a,b){
//         console.log(a, "mahir vado a")
//         console.log(b, "mahir vado b")

//     }

//     dax(x,y){
//         console.log(x, "dax vado x")
//         console.log(y, "dax vado y")
//     }
// }

// const result = new maxgen(10,20,30)

// result.mahir(20,30);
// result.dax(40,50);

// object ma ---------
// const person ={
//     fName:"mahir",
//     lName:"prajapati"
// }
// console.log(person.fName)

// constructor na main 3 rule --------------

//1. It has to have the exact name "constructor"
//2. It is executed automatically when a new object is created
//3. It is used to initialize object properties

// e.g.1---------------

// class Car {

//     constructor(name, year) {
//       this.name = name;   //this.name = ford
//       this.year = year;   // this.year = 2014
//     }

//   }

//   const myCar1 = new Car("Ford", 2014);
//   const myCar2 = new Car("Audi", 2019);

//  console.log( myCar1.name, myCar1.year);
//  console.log( myCar2.name, myCar2.year);

// e.g.2 -----------------------------------------------

// class virat{
//     constructor(bigFan,century,ranking,wife){
//         console.log("his biggest fan is"+ " "+ bigFan);
//         console.log("his total icc century is"+ " "+ century);
//         console.log("his overall icc rank is"+ " "+ ranking);
//         console.log("his wife name is"+ " "+ wife);
//     }

//     dhoni(x){
//         console.log("He is popular by" + " "+ x +" "+ "name")
//     }
//     sachin(y){
//         console.log("He is a God Of"+" "+y)
//     }
// }

// const kohli = new virat("neel",80,1,"Anushka");
// kohli.dhoni("Thala");
// kohli.sachin("Cricket");

// e g 3-----------------------------------------------------

// class Car {
//     constructor(name, year) {
//       this.name = name; //ford
//       this.year = year; // 2014
//     }

//     age() {
//       const date = new Date();
//       return date.getFullYear() - this.year;
//     }
//   }

//   const myCar = new Car("Ford", 2014);

//  console.log( "My car is " + myCar.age() + " years old.");

// Inheritence -------------------------------------------

// extend ---- keyword
// inheritence meaning => koi 1 class bijaa class ne potana class sathe extend kre (bhega kre). tene class nu inheritence thayu kehvaay.
// super => super keyword refer krse parent class ne

// e.g -------------

// here "dax" class is parent class AND
// "mahir" class is child class of "dax" class

// class neel{
//     constructor(a){
//         const khajano = a;
//     }
// }

// class dax{
//     constructor(x){
//         // let money = x
//     }
// }

// class mahir extends dax extends neel{
//     constructor(x,y){
//         super(x)
//         let finalMoney = x+y;
//         console.log(finalMoney);
//     }
// }

// const result = new mahir(1000,1000);

// Getter and Setter

// class Car {
//     constructor(brand) {
//       this.carname = brand;
//     }
//     get cnam() {
//       return this.carname;
//     }
//     set cnam(x) {
//       this.carname = x;
//     }
//   }

//   const myCar = new Car("Ford");

//   document.getElementById("demo").innerHTML = myCar.cnam;

// -------------

// class Car {
//     constructor(brand) {
//       this._carname = brand;
//     }
//     set carname(x) {
//       this._carname = x;
//     }
//     get carname() {
//       return this._carname;
//     }
//   }

//   const myCar = new Car("Ford");
//   myCar.carname = "Volvo";
//   document.getElementById("demo").innerHTML = myCar.carname;
