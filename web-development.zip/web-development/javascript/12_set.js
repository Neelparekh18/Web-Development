// console.log("hey set dhyan rakje taru...")

// syntax ------------------

// const s = new Set([1,2,3,4,5]);
// console.log(s);

// const arr = [1,2,3,4,5];
// console.log(arr)

// set methods

// 1. create a new set-------------------------

// const s = new Set();
// console.log(s)

// const arr = [1,2,3,4,5,2,3];
// console.log(arr);

// const s = new Set([1,2,3,4,5,2,3]);
// console.log(s)

// 2. Adds a new element to the Set-----------------------

// const s = new Set([1,2]);

// s.add(3);
// s.add(4);
// s.add(0);
// s.add(3);
// s.add(3);
// s.add(3);
// s.add(3);

// console.log(s)

// ----------------------------------------------------
// question ------
// add element in the array

// let arr = [1,2,4,5,6];

// add element 3 after element 2
// let arr =[1,2,4,5,6];
// arr.shift();
// arr.shift();
// arr.unshift(3);
// arr.unshift(2);
// arr.unshift(1);

// console.log(arr);
// ----------------------------------
// arr[2] = 3;
// console.log(arr)
// -----------------------------------

// 3. Removes an element from a Set-------

// delete();

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);

// console.log(s)

// s.delete("a")
// // console.log(delete s[1])
// console.log(s)

// 4. Returns true if a value exists---------------

// has()

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);

// console.log(s.has(1))
// console.log(s.has(11))

// 5. Removes all elements from a Set------------------

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);
// console.log(s.size)
// s.clear();
// console.log(s)

// 6. Invokes a callback for each element-------------------

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);

// s.forEach((x)=>{
//     console.log(x)
// })

// // 7. values()------------------------------------------

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);
// console.log(s.values())

// 7. keys()------------------------------------------
// same as values
// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);
// console.log(s.keys());

// 7. entries()------------------------------------------

// const s = new Set([1,2,3,4,5,"a","b","c","d","e"]);
// console.log(s.entries())
