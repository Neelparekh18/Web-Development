// console.log("hello function");

// syntax -------------------------

// function myFunction(){
//     // ....codee

// }

// function ne called (function na naam perthi call krsu)

// myFunction()

// function cricket(){
//     console.log("hello cricket from function");
// }
// cricket();

// function maths(x,y){
//     // const z = x+y;
//     // console.log(z)
// console.log(x)
// console.log(y)

// }

// maths(10,20)

// function func(a,b,c,d,e,f){
//     console.log(a+b+c+d+e+f);
// };

// func(1,2,3,4,5,6,7,8,9,10);

// function myFunc(x,y){
//     const z = x+y;
//     return z;
// };

// console.log(myFunc(10,20)) or

// const result = myFunc(10,20);
// console.log(result)
