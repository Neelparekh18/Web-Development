$(document).ready(function () {


    $("#form").submit(function(){

        const nameValue = $("#name").val();
        // alert(nameValue);
        const emailValue = $("#email").val();
        const mobileValue = $("#mobile").val();
        const passwordValue = $("#pass").val();


        const nameRegex = /^[A-Za-z ]+$/;
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
        const mobileRegex = /^\d{10}$/
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]).{8,}$/




        // alert( passwordValue)

            if(nameValue == ""){
                alert("Name must be filled out")
                // $("#span-name").show();
            }else if(emailValue == ""){
                alert("email must be filled out")
            }else if(mobileValue == ""){
                alert("mobile must be filled out")
            }else if(passwordValue == ""){
                alert("password must be filled out")
            }else if(!nameRegex.test(nameValue)){
                alert("Please enter a valid name.")
            }else if(!emailRegex.test(emailValue)){
                alert("Please enter a valid email.")
            }else if(!mobileRegex.test(mobileValue)){
                alert("Please enter a valid mobile.")
            }else if(!passwordRegex.test(passwordValue)){
                alert("Please enter a valid password.")
            }else{
                alert("form submitted successfully");
            }



    })
  



});
