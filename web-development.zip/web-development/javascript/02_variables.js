// console.log("hello variables");

// 1995

// 3 types => 1. var 2. let 3. const

// variable => value store krva mate.

// var price = 500;
// var name = "mahir";
// var age = 20;
// var roll = 1;
// var language = "JS";

// console.log(name)
// console.log(price)
// console.log(age)

// console.log(name,age,price,roll,language)

// console.log(name +" "+ roll +" "+ age +" "+ language)

// let mahir
// const mahir

// differnces
// 1.var
// => re-declare thay skse
// => value update thay skse

// example :

// var x = 10;
// console.log(x)
// var x = 20;
// console.log(x);
// console.log(x)

// 2.let
// => re-declare nay thay skse
// => value update thay skse

// let x = 10;
// // let x = 20;
// x = 20;   (automatically)
// console.log(x)

// 3. const

// => re-declare nay thay skse
// => value update pn nay thay skse

// const x = 100;
// console.log(x)

// var namee = "mahir";
// console.log(namee)
// // const x = 200;
// x = 200;

// console.log(x);

// differnce between "=" and "=="

// let k = 500 // it means we assign 500 into k variable
// console.log(k);

// let x = 100;
// let y = 1000;
// console.log(x==y);

// let z = x==y;
// console.log(z)

// var x = 20;
// var z = x;
// console.log(z)
