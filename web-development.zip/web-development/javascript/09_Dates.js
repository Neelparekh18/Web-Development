// js Dates

// syntax

// real date and time
// const d = new Date();
// console.log(d);

// manual date

// const d = new Date("2005-06-23");
// console.log(d);

// get method and set method

// const date = new Date();

// console.log(date)

// => get hour

// const result = date.getHours();
// console.log(result);

// => get seconds

// const result = date.getSeconds();
// console.log(result)

// => get getMilliseconds

// const result = date.getMilliseconds();
// console.log(result)

// => get day
// const result = date.getDay();
// console.log(result);

// => --------------------------------------
// 7 numbers specify year, month, day, hour, minute, second, and millisecond (in that order):

// const d = new Date(2018, 0, 25, 10, 33, 30, 0);
// console.log(d)

// const d = new Date(2018, 0, 25);
// console.log(d)

// => set method

// date month year (aadhar stambh chho)

// const d = new Date();
// d.setFullYear(2020);
// console.log(d)
// 2 dec 2020

// d.setMinutes(20)
// console.log(d)

// const d = new Date(2018, 0, 25, 10, 33, 30, 0);

// d.setMinutes(20);
// d.setDate(28);
// console.log(d)

// console.log("bye bye moye moye")
