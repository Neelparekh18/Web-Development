// console.log("if-else");

// syntax ---------------------
// single if else mate -----------------
// if ( condition ) {
// code ... (jo condition true)
// } else{
// code ...(jo condition false)
// }

// multiple if else mate ----------------
// if ( condition ) {
// code ... (jo condition true)
// } else if(){
// code ... (jo condition true)
// }else if(){
// code ... (jo condition true)
// }else{
// code ...(jo condition false)
// }

// ------------------------------------------
// var name = "mahir";

// if(name == "mahirr"){
//     console.log("ha bhai sachi vat");
// }else{
//     console.log("na bhai khoti vat");
// }

// ----------------------------------------

// let age = 20;
// let  age = 15;

// if(age >= 18){
//     console.log("you can drive a car");
// }else{
//     console.log("tu hju dudh pi");
// }

// ----------------------------------------

// let age = 20;
// let age = 10;
// let age = 16;

// if(age>=18){
//     console.log("bindaas eni mane rakhd tuuuu gadi laineee");
// }else if(age>=16){
//     console.log("tu chaalay na nathiii pn thodu maap maaa hoooo kachu licence kadhaayi deje")
// }else{
//     console.log("tu hju dudh pi tuu revaaaj deee moye moye thay jse nakar");
// }

// -------------------------------------------

// let rank = 4656;

// if(rank==1){
//     console.log("austrelia same ramse");
// }else if(rank==2){
//     console.log("South Africa same ramse")
// }else if(rank==3){
//     console.log("newzeland same ramse")
// }else{
//     console.log("pakistan same ramse")
// }
