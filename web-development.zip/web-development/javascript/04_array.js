// console.log("hello Array")

// syntax

// let arr =["","","".....]

// let arr = [10,20,30,40,50];
// console.log(arr)

// let arr = ["js","html","css","node","java",'python'];
// console.log(arr)

// create blank array

// let arr = [];
// console.log(arr)

// add values according to  index
// arr[0]= 1;
// arr[1]=3;
// arr[2]=5;
// arr[3]=7;
// arr[4] = 10;
// console.log(arr)

// array methods

// 1. length

// let arr = [1,2,3,4,5,6];

// console.log(arr[4])
// let result = arr.length;
// console.log(arr.length)
// console.log(result)

// 2. pop and push

// let arr = [20,10,40,30,50,60];
// arr.push(70);
// arr.pop()
// arr.push(80)
// arr.pop();
// arr.push(100);
// arr.push(200);
// arr.pop();
// arr.push(90);
// arr.pop();

// console.log(arr)

// 3. shift and unshift

// let arr = [20,30,40];
// arr.unshift(10);
// arr.shift()
// console.log(arr)

// 4. join method

// let arr1 =[12,13,14,15];

// console.log(arr1.join(","))

// 5.delete method

// let arr  = [1,2,3,4,5,6,7,8,9,10];

// console.log(arr)
// arr.pop();
// arr.shift()
// console.log(arr)

// delete arr[9];
// delete arr[0];
// console.log(arr)

// 6. concat

// let arr1 = [1,2,3,4,5];
// let arr2 = [6,7,8,9,10];
// let arr3 = [11,12,13,14,15]

// console.log(arr1.concat(arr3,arr2))

// 7. slice

// let arr = ["html","css","py","java","js","flutter"];

// syntax => (start,end)    => starting index include thase and ending index ee exclude

// console.log(arr.slice(1,4))
// console.log(arr.slice(3));
// console.log(arr.slice(2,5))
// console.log(arr[6])

// console.log(arr.slice(-5))
// console.log(arr.slice(-5,-2))

// 8. splice

// let arr = ["html","css","py","java","js","flutter"];

// syntax => (start,length)
// console.log(arr.splice(2,2))
// arr.splice(2,2)
// jyare more than 2 parameters tyare syntax = (start,jetli length etli length ni value delete, add value on start index )
//  arr.splice(2,1,"dart")
// console.log(arr)

// Array sorting

// let arr = [2,45,11,40,100,25];

// console.log(arr.sort(function (a,b){
//     return a-b ;
// }));

// mahir ans => 2,11,25,40,45,100
// JavaScript ans => 100, 11, 2, 25, 40, 45

// console.log(arr.sort())
// console.log(arr.reverse());
