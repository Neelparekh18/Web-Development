// console.log("hello loops ben")
// 1. for loop
// 2. for of loop
// 3. for in loop
// 4. while loop
// 5. do while loop
// 6. forEach loop

// for loop ----------------------

// syntax
// for( initial value; condition; inc/dec ){

// code .......

// }

// e.g =>

// i++ = > i=i+1
// i+=2 => i=i+2

// for(let i=0; i<11; i+=2){
//     console.log(i)
// }

// print 1  to 99 in for loop

// for(let i=1; i<100; i++){
//     console.log(i)
// }

// print only even numbers in 1 to 100

// 1st way =>

// for(let i=2; i<=100; i+=2){
//     console.log(i)
// }

// 2nd way =>

// for(let i=1 ; i<=100;i++){
//     if(i%2 == 0){
//         console.log(i)
//     }
// }

// print only odd numbers in 1 to 100

// for (let i = 1; i <= 100; i++) {
//   if (i % 2 !== 0) {
//     console.log(i);
//   }
// }

// let arr = ["jeep","audi","tata","mercedz","bmw","alto"];
// console.log(arr[0])
// console.log(arr[1])
// console.log(arr[2])
// console.log(arr[3])

// let len = arr.length;

// for(let i=0; i<arr.length;i++){
//     console.log(arr[i])
// }

// for(let i=0; i<arr.length;i++){
//     if(i%2 !== 0){
//         console.log(arr[i])
//     }
// }

// for(let i=0; i<arr.length;i+=3){
//     console.log(arr[i])
// }

// break and continue; (statement)

// break => jump out from the loop
// continue => jump out only on given condition

// for(let i=0 ; i<=10;i++){

//     if(i==5){
//         break;
//     }

//     console.log(i)

// }

// for(let i=0 ; i<=10;i++){

//     if(i==5){
//         continue;
//     }

//     console.log(i);

// }

// print 1 to 50 (except - 10,20,30,40)

// for(let i=1; i<=50;i++){
//     if(i==10){
//         continue;
//     }
//     if(i==20){
//         continue;
//     }
//     if(i==30){
//         continue;
//     }
//     if(i==40){
//         continue;
//     }
//     console.log(i);
// }

// for(let i=1; i<=50;i++){
//     if(i==10 || i==20 || i==30 || i==40){
//         continue;
//     }
//     if(i==41){
//         break;
//     }
//     console.log(i);
// }

// While loop---------------------------------

// syntax

// let i =0;

// while(i<=10){
//     console.log(i);
//     i++;
// }

// do while loop

// do{
// code ...
// }while(condition)

// let i=0;

// do{
//     console.log(i);
//     i++;
// }while(i<=10);

// => differneces

// let i =51;

// while(i<30){
//     console.log(i)
//     i++;
// }

// let i=51;

// do{
//     console.log(i);
//     i++;
// }while(i<30)

// forEach loop ---------------------------

let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// syntax--

// arr.forEach((x)=>{
//     console.log(x);
// })

// for of and for in loop ------------------

// syntax --------------

// for ( variable of iterable){
//     // code ...
// }

// for ( variable in iterable){
//     // code ...
// }

// let ipo = [1,2,3,4,5,6,7,8,9];

// for(x of ipo){
//     console.log(x)
// }

// for(x in ipo){
//     console.log(x)
// }
