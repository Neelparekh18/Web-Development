// console.log("hello string")
// let hello = "js";
// console.log(hello)

// ------------------------------------------------------------------------
// syntax =>  " .... " or '...'

// const str = "hello kajukatri from double coated";
// const str = 'hello kajukatri from single coated';

// console.log(str);

// const s = "javascript";
// const ss = "js18";

// console.log(s);
// console.log(ss);

// const num = "18vk";

// console.log(typeof num)

// ------------------------------------------------------------------------
// methods ---

// 1. length -----------

// const str = "javascript";

// console.log(str.length);

// 2. slice

// const str = "javascript";

// const result = str.slice(4,10)
// console.log(result)

// 3. substring

// const str = "javascript";

// console.log(str.slice(-8,8))
// const result = str.substring(-8,8)
// console.log(result)

// 4. substr

// const str = "javascript";
// console.log(str.slice(1,4))
// console.log(str.substr(1,4))

// 5. replace

// const fruits = "jamfal, chiku, keri, safarjan, keri, keri";

// console.log(fruits.replace("keri","mango"))

// console.log(fruits.replace(/Keri/i,"mango"));

// console.log(fruits.replace(/Keri/ig,"mango"));

// console.log(fruits.replace(/keri/g,"mango"));

// console.log(fruits.replace("safarjan","apple"))

// 6. replaceAll

// const fruits = "jamfal, chiku, keri, safarjan, keri";
// console.log(fruits.replaceAll("keri","mango"))

// 7. toUpperCase---------------

// const str = "java";
// console.log(str)
// console.log(str.toUpperCase());

// 8. toLowerCase---------------

// const str = "JAVA";
// console.log(str)
// console.log(str.toLowerCase());

// 9. concat

// const str1 = "java";
// const str2 = "python";
// const str3 = "moyeMoye"

// console.log(str1.concat(" ",str2," ", str3))

// 10. trim , trimStart , trimEnd

// const str = "    javascript   ";
// console.log(str.length);

// const t = str.trim();
// console.log(t.length)

// const ts = str.trimStart();
// console.log(ts.length);

// const te = str.trimEnd();
// console.log(te.length);

// 11. padStart and padEnd

// const str = "js";

// console.log(str.padStart(5,"x"))
// console.log(str.padEnd(5,"x"))

// 12. charAt

// const str = "java, python, flutter";

// console.log(str.charAt(3));
// console.log(str.charAt(2));
// console.log(str.charAt(4));

// 13.charCodeAt

// const str = "javab, python, flutter";
// console.log(str.charCodeAt(3));
// console.log(str.charAt(4));
// console.log(str.charCodeAt(4));

// 14. split

// const str = "js|py|,|js||moye";

// console.log(str.split("|,|"))
