// console.log("i am operator")

//  + , - , / , * ,**, % , > , < , >= , <= , increment ++, decrement --,  Assignment Operators (+=,-=,*=,/+,%=,**=)

// console.log(1+2);
// console.log(1-2)
// console.log(1*2)
// console.log(1/2)

// let x = 10;
// let y = 20;

// let z = x+y;
// console.log(z);

// let z = x-y;
// console.log(z)

// let z = x*y;
// console.log(z)

// let z = x/y;
// console.log(z)

// let a = 21;
// let b = 2;

// console.log(a%b)

// let p = 200;
// let q = 100;

// console.log(p>q);
// console.log(p<q);

// let m = 1;
// let n = 1;

// console.log(m==n)
// console.log(m<n);
// console.log(m>n);
// console.log(m<=n);
// console.log(m>=n);

// let i = 10;
// let a = i+1;
// console.log(a);

// i++;
// i++;
// i--;
// i++;
// i--;

// console.log(i)

// Assignment Operators

// let x = 10;

//  x+=5;    //(x+=5) => it means x = x+5
// x-=5         // => x = x-5
// x*=5         // => x = x*5
// x/=5         // => x = x/5
//  console.log(x)

// let x = 50;

// let y = 100;

// const res = x*y;

// console.log(x+=y)    //150
// console.log(x-=y)   // -50   x-=y => x= x-y
// console.log(x/=y)   //  0.5
// console.log(x*y)   //5000
// console.log(x*y)

// console.log(50%100)

// ** (exponential operator);

// let a = 2;
// let b = 3;
// console.log(a**b)
// console.log(b**a)

// pow operator

// let a = 5;
// let b = 6;
// // console.log(a)
// console.log(Math.pow(a,b))
